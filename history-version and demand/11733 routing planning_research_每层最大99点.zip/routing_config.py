''' 速度基数 越大越慢 '''
speed_base = 1e-3
''' 数据产生速度（越小越快） '''
generate_speed = 1.0
generate_buffer = 20
''' 数据上传 速度（越小越快） '''
send_speed = 0.2
send_buffer = 20
''' 数据接收速度（越小越快） '''
receive_speed = 0.2
receive_buffer = 20
''' 数据处理速度（越小越快） '''
processing_speed = 1.0

''' 各层节点数量(第一层为cloud，最后层为IoT/user） '''
each_layer_nodes_num = [1, 2, 8, 16]

''' 不同层CPU算力差值: 倍数关系（非指数级）(值越大，运算越慢） '''
diff_layers_cpu_performance = [1, 80, 80, 80, 40, 50, 60, 70, 80, 90, 100]

''' 定义各层距离cloud节点的半径距离 '''
diff_layer_radius = [ 0, 10, 20, 30, 40, 50, 60, 70, 80, 90]  # 定义各层节点所在圆的半径（距离云的距离）
''' 定义各层距离cloud节点的角度分布 '''
diff_layer_angle = [[60, 120], [30, 150], [30, 150], [30, 150], [30, 150], [30, 150],
                       [30, 150], [30, 150], [30, 150], [30, 150]]  # 定义云上各节点的方位分布范围（角度范围）

''' 设置最大距离通信成本，超出该值的节点无法建立连接 '''
max_distance_cost = 1000

''' 同层CPU算力差值范围 倍数关系（非指数级）(值越大，运算越慢，1：为该层初始水平） '''
one_layer_cpu_performance = [0.5, 1.5]

''' 产生的数据总量(字节大小） '''
generate_totalSize = 10000

''' 不同层产生的数据总量: 倍数关系（非指数级） '''
diff_layer_generate_totalSize = None  ## 默认与 diff_layers_cpu_performance 一致

''' CPU算力（延时）公式 '''
get_delay_time = lambda layer_idx, rand_perf: speed_base*layer_idx*rand_perf

''' MDAR算法开关 '''
MDAR_BUTTON = True

''' ODAS 开关 '''
ODAS_BUTTON = True
ODAS_rate = 0.5

''' 负载均衡开关 '''
Balance = True

''' 数据种类数量 '''
data_class_num = 1

''' 相似度范围 '''
similar_range = [0, 1]

''' 数据保存文件名 '''
save_path = './log/'
